import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { getHouse } from "../../redux/actions";

// CUIDADOOOO. SI O SI FUNCTIONAL COMPONENT! SE ROMPEN LOS TEST EN CASO CONTRARIO!!
// TAMBIEN VAS A TENER QUE USAR HOOKS!
const HouseDetail = (props) => {
  const dispatch = useDispatch();
//   const name = useSelector((state) => state.name);
//   const words = useSelector((state) => state.words);

  React.useEffect(() => {
    const houseId = props.match.params.houseId;
    dispatch(getHouse(houseId));
  }, [dispatch]);

  return (
    <div>
      {/* <p>{name}</p>
      <p>{words}</p> */}
    </div>
  );
};

export default HouseDetail;
