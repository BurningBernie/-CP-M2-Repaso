import React from 'react';

// CUIDADOOOO. SI O SI FUNCTIONAL COMPONENT! SE ROMPEN LOS TEST EN CASO CONTRARIO!!
const CharacterCard = () => {
    
    return (
        <div>

        </div>
    );
};

export default CharacterCard;
